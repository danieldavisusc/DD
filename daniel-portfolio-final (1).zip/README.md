# Daniel Davis Finance Portfolio

Files included:
- `index.html`
- `resume.pdf`
- `research-paper.pdf`

To publish on GitHub Pages:
1. Create a repository named `danieldavisusc.github.io`
2. Upload all files to the repository root
3. In Settings > Pages, set Source to `Deploy from a branch`
4. Select branch `main` and folder `/(root)`
5. Save and wait for the site link to appear

Keep the filenames exactly the same so the links work.
