# Daniel Davis Portfolio

Files for GitHub Pages:
- index.html
- resume.pdf
- research-paper.pdf

Upload all three files to the root of your GitHub Pages repository.
